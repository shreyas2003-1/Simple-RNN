# RNN Tweet Classification

This repository contains an RNN-based model for classifying tweets. The workflow includes:

## Files:
1. **Simple Rnn model (1).ipynb** - Jupyter Notebook for training and evaluating the model.
2. **Workflow Diagram** - A visual representation of the RNN pipeline.

## Steps to Use:
1. Clone the repository and open the Jupyter notebook.
2. Follow the steps in the notebook to preprocess data, train, and evaluate the model.
3. Refer to the workflow diagram for understanding the data flow.

### Dependencies:
- TensorFlow / Keras
- Pandas
- NumPy

### Author:
[Your Name]

---
